import RandomDataGenerator from './random-data-generator/RandomDataGenerator'
const RND = new RandomDataGenerator()
export default RND
