/**
 * @callback Phaser.Types.Tilemaps.CreateFromObjectsClassTypeConstructor
 * @since 3.60.0
 *
 * @param {Phaser.Scene} scene - The Scene to which this Game Object belongs.
 */
