/**
 * @author       Richard Davey <rich@photonstorm.com>
 * @copyright    2020 Photon Storm Ltd.
 * @license      {@link https://opensource.org/licenses/MIT|MIT License}
 */

import Contains from './Contains'

import GetPoint from './GetPoint'
import GetPoints from './GetPoints'
import GEOM_CONST from '../const'
import Line from '../line/Line'
import Random from './Random'

/**
 * @classdesc
 * Encapsulates a 2D rectangle defined by its corner point in the top-left and its extends in x (width) and y (height)
 *
 * @class Rectangle
 * @memberof Phaser.Geom
 * @constructor
 * @since 3.0.0
 *
 * @param {number} [x=0] - The X coordinate of the top left corner of the Rectangle.
 * @param {number} [y=0] - The Y coordinate of the top left corner of the Rectangle.
 * @param {number} [width=0] - The width of the Rectangle.
 * @param {number} [height=0] - The height of the Rectangle.
 */
export class Rectangle {
  constructor(x, y, width, height) {
    if (x === undefined) {
      x = 0
    }
    if (y === undefined) {
      y = 0
    }
    if (width === undefined) {
      width = 0
    }
    if (height === undefined) {
      height = 0
    }

    /**
     * The geometry constant type of this object: `GEOM_CONST.RECTANGLE`.
     * Used for fast type comparisons.
     *
     * @name Phaser.Geom.Rectangle#type
     * @type {number}
     * @readonly
     * @since 3.19.0
     */
    this.type = GEOM_CONST.RECTANGLE

    /**
     * The X coordinate of the top left corner of the Rectangle.
     *
     * @name Phaser.Geom.Rectangle#x
     * @type {number}
     * @default 0
     * @since 3.0.0
     */
    this.x = x

    /**
     * The Y coordinate of the top left corner of the Rectangle.
     *
     * @name Phaser.Geom.Rectangle#y
     * @type {number}
     * @default 0
     * @since 3.0.0
     */
    this.y = y

    /**
     * The width of the Rectangle, i.e. the distance between its left side (defined by `x`) and its right side.
     *
     * @name Phaser.Geom.Rectangle#width
     * @type {number}
     * @default 0
     * @since 3.0.0
     */
    this.width = width

    /**
     * The height of the Rectangle, i.e. the distance between its top side (defined by `y`) and its bottom side.
     *
     * @name Phaser.Geom.Rectangle#height
     * @type {number}
     * @default 0
     * @since 3.0.0
     */
    this.height = height
  }

  /**
   * Checks if the given point is inside the Rectangle's bounds.
   *
   * @method Phaser.Geom.Rectangle#contains
   * @since 3.0.0
   *
   * @param {number} x - The X coordinate of the point to check.
   * @param {number} y - The Y coordinate of the point to check.
   *
   * @return {boolean} `true` if the point is within the Rectangle's bounds, otherwise `false`.
   */
  contains(x, y) {
    return Contains(this, x, y)
  }

  /**
   * Calculates the coordinates of a point at a certain `position` on the Rectangle's perimeter.
   *
   * The `position` is a fraction between 0 and 1 which defines how far into the perimeter the point is.
   *
   * A value of 0 or 1 returns the point at the top left corner of the rectangle, while a value of 0.5 returns the point at the bottom right corner of the rectangle. Values between 0 and 0.5 are on the top or the right side and values between 0.5 and 1 are on the bottom or the left side.
   *
   * @method Phaser.Geom.Rectangle#getPoint
   * @since 3.0.0
   *
   * @generic {Phaser.Geom.Point} O - [output,$return]
   *
   * @param {number} position - The normalized distance into the Rectangle's perimeter to return.
   * @param {(Phaser.Geom.Point|object)} [output] - An object to update with the `x` and `y` coordinates of the point.
   *
   * @return {(Phaser.Geom.Point|object)} The updated `output` object, or a new Point if no `output` object was given.
   */
  getPoint(position, output) {
    return GetPoint(this, position, output)
  }

  /**
   * Returns an array of points from the perimeter of the Rectangle, each spaced out based on the quantity or step required.
   *
   * @method Phaser.Geom.Rectangle#getPoints
   * @since 3.0.0
   *
   * @generic {Phaser.Geom.Point[]} O - [output,$return]
   *
   * @param {number} quantity - The number of points to return. Set to `false` or 0 to return an arbitrary number of points (`perimeter / stepRate`) evenly spaced around the Rectangle based on the `stepRate`.
   * @param {number} [stepRate] - If `quantity` is 0, determines the normalized distance between each returned point.
   * @param {(array|Phaser.Geom.Point[])} [output] - An array to which to append the points.
   *
   * @return {(array|Phaser.Geom.Point[])} The modified `output` array, or a new array if none was provided.
   */
  getPoints(quantity, stepRate, output) {
    return GetPoints(this, quantity, stepRate, output)
  }

  /**
   * Returns a random point within the Rectangle's bounds.
   *
   * @method Phaser.Geom.Rectangle#getRandomPoint
   * @since 3.0.0
   *
   * @generic {Phaser.Geom.Point} O - [point,$return]
   *
   * @param {Phaser.Geom.Point} [point] - The object in which to store the `x` and `y` coordinates of the point.
   *
   * @return {Phaser.Geom.Point} The updated `point`, or a new Point if none was provided.
   */
  getRandomPoint(point) {
    return Random(this, point)
  }

  /**
   * Sets the position, width, and height of the Rectangle.
   *
   * @method Phaser.Geom.Rectangle#setTo
   * @since 3.0.0
   *
   * @param {number} x - The X coordinate of the top left corner of the Rectangle.
   * @param {number} y - The Y coordinate of the top left corner of the Rectangle.
   * @param {number} width - The width of the Rectangle.
   * @param {number} height - The height of the Rectangle.
   *
   * @return {this} This Rectangle object.
   */
  setTo(x, y, width, height) {
    this.x = x
    this.y = y
    this.width = width
    this.height = height

    return this
  }

  /**
   * Resets the position, width, and height of the Rectangle to 0.
   *
   * @method Phaser.Geom.Rectangle#setEmpty
   * @since 3.0.0
   *
   * @return {this} This Rectangle object.
   */
  setEmpty() {
    return this.setTo(0, 0, 0, 0)
  }

  /**
   * Sets the position of the Rectangle.
   *
   * @method Phaser.Geom.Rectangle#setPosition
   * @since 3.0.0
   *
   * @param {number} x - The X coordinate of the top left corner of the Rectangle.
   * @param {number} [y=x] - The Y coordinate of the top left corner of the Rectangle.
   *
   * @return {this} This Rectangle object.
   */
  setPosition(x, y) {
    if (y === undefined) {
      y = x
    }

    this.x = x
    this.y = y

    return this
  }

  /**
   * Sets the width and height of the Rectangle.
   *
   * @method Phaser.Geom.Rectangle#setSize
   * @since 3.0.0
   *
   * @param {number} width - The width to set the Rectangle to.
   * @param {number} [height=width] - The height to set the Rectangle to.
   *
   * @return {this} This Rectangle object.
   */
  setSize(width, height) {
    if (height === undefined) {
      height = width
    }

    this.width = width
    this.height = height

    return this
  }

  /**
   * Determines if the Rectangle is empty. A Rectangle is empty if its width or height is less than or equal to 0.
   *
   * @method Phaser.Geom.Rectangle#isEmpty
   * @since 3.0.0
   *
   * @return {boolean} `true` if the Rectangle is empty. A Rectangle object is empty if its width or height is less than or equal to 0.
   */
  isEmpty() {
    return this.width <= 0 || this.height <= 0
  }

  /**
   * Returns a Line object that corresponds to the top of this Rectangle.
   *
   * @method Phaser.Geom.Rectangle#getLineA
   * @since 3.0.0
   *
   * @generic {Phaser.Geom.Line} O - [line,$return]
   *
   * @param {Phaser.Geom.Line} [line] - A Line object to set the results in. If `undefined` a new Line will be created.
   *
   * @return {Phaser.Geom.Line} A Line object that corresponds to the top of this Rectangle.
   */
  getLineA(line) {
    if (line === undefined) {
      line = new Line()
    }

    line.setTo(this.x, this.y, this.right, this.y)

    return line
  }

  /**
   * Returns a Line object that corresponds to the right of this Rectangle.
   *
   * @method Phaser.Geom.Rectangle#getLineB
   * @since 3.0.0
   *
   * @generic {Phaser.Geom.Line} O - [line,$return]
   *
   * @param {Phaser.Geom.Line} [line] - A Line object to set the results in. If `undefined` a new Line will be created.
   *
   * @return {Phaser.Geom.Line} A Line object that corresponds to the right of this Rectangle.
   */
  getLineB(line) {
    if (line === undefined) {
      line = new Line()
    }

    line.setTo(this.right, this.y, this.right, this.bottom)

    return line
  }

  /**
   * Returns a Line object that corresponds to the bottom of this Rectangle.
   *
   * @method Phaser.Geom.Rectangle#getLineC
   * @since 3.0.0
   *
   * @generic {Phaser.Geom.Line} O - [line,$return]
   *
   * @param {Phaser.Geom.Line} [line] - A Line object to set the results in. If `undefined` a new Line will be created.
   *
   * @return {Phaser.Geom.Line} A Line object that corresponds to the bottom of this Rectangle.
   */
  getLineC(line) {
    if (line === undefined) {
      line = new Line()
    }

    line.setTo(this.right, this.bottom, this.x, this.bottom)

    return line
  }

  /**
   * Returns a Line object that corresponds to the left of this Rectangle.
   *
   * @method Phaser.Geom.Rectangle#getLineD
   * @since 3.0.0
   *
   * @generic {Phaser.Geom.Line} O - [line,$return]
   *
   * @param {Phaser.Geom.Line} [line] - A Line object to set the results in. If `undefined` a new Line will be created.
   *
   * @return {Phaser.Geom.Line} A Line object that corresponds to the left of this Rectangle.
   */
  getLineD(line) {
    if (line === undefined) {
      line = new Line()
    }

    line.setTo(this.x, this.bottom, this.x, this.y)

    return line
  }

  /**
   * The x coordinate of the left of the Rectangle.
   * Changing the left property of a Rectangle object has no effect on the y and height properties. However it does affect the width property, whereas changing the x value does not affect the width property.
   *
   * @name Phaser.Geom.Rectangle#left
   * @type {number}
   * @since 3.0.0
   */

  get left() {
    return this.x
  }

  set left(value) {
    if (value >= this.right) {
      this.width = 0
    } else {
      this.width = this.right - value
    }

    this.x = value
  }

  /**
   * The sum of the x and width properties.
   * Changing the right property of a Rectangle object has no effect on the x, y and height properties, however it does affect the width property.
   *
   * @name Phaser.Geom.Rectangle#right
   * @type {number}
   * @since 3.0.0
   */

  get right() {
    return this.x + this.width
  }

  set right(value) {
    if (value <= this.x) {
      this.width = 0
    } else {
      this.width = value - this.x
    }
  }

  /**
   * The y coordinate of the top of the Rectangle. Changing the top property of a Rectangle object has no effect on the x and width properties.
   * However it does affect the height property, whereas changing the y value does not affect the height property.
   *
   * @name Phaser.Geom.Rectangle#top
   * @type {number}
   * @since 3.0.0
   */

  get top() {
    return this.y
  }

  set top(value) {
    if (value >= this.bottom) {
      this.height = 0
    } else {
      this.height = this.bottom - value
    }

    this.y = value
  }

  /**
   * The sum of the y and height properties.
   * Changing the bottom property of a Rectangle object has no effect on the x, y and width properties, but does change the height property.
   *
   * @name Phaser.Geom.Rectangle#bottom
   * @type {number}
   * @since 3.0.0
   */

  get bottom() {
    return this.y + this.height
  }

  set bottom(value) {
    if (value <= this.y) {
      this.height = 0
    } else {
      this.height = value - this.y
    }
  }

  /**
   * The x coordinate of the center of the Rectangle.
   *
   * @name Phaser.Geom.Rectangle#centerX
   * @type {number}
   * @since 3.0.0
   */

  get centerX() {
    return this.x + this.width / 2
  }

  set centerX(value) {
    this.x = value - this.width / 2
  }

  /**
   * The y coordinate of the center of the Rectangle.
   *
   * @name Phaser.Geom.Rectangle#centerY
   * @type {number}
   * @since 3.0.0
   */

  get centerY() {
    return this.y + this.height / 2
  }

  set centerY(value) {
    this.y = value - this.height / 2
  }
}
