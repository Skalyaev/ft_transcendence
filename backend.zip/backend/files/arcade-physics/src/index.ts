/**
 * @author       Yannick Deubel (https://github.com/yandeu)
 * @copyright    Copyright (c) 2022 Yannick Deubel
 * @license      {@link https://opensource.org/licenses/MIT | MIT License}
 */

export { ArcadePhysics } from './physics/arcade/ArcadePhysics'
