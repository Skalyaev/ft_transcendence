module.exports = {
  ignore: ['node_modules', 'lib', 'src']
}
